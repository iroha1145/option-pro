# Validation — discovery v2

Checkpoints are a separate scoring run from return_pack/. Entry lists are an invariant.
Discovery comparisons are G2-G1 and G3-G2. Technical comparison is G1-B0.

- scope: `restricted_current_membership_exploratory`
- Labels use the restricted current-membership panel and its exchange calendar. This is not a full-market excess return.
- production anchor: `d16b25e3812dce9adf16e2ca993b4f2c38d7b1ef`
- bars sha256: `1e48727adbd6abc055f6b9c759d371c07ead1fbc177d4b13deadbdc5d68ae589`
- this-run scoring hashes: `{"candidates_sha256": "e64e69630f409b136afe72c75e5fc93359281d01637feab2a24ceec7076623a7", "adapter_sha256": "37557eeb4538839fd844d62c754e80ad0613e05d2fca0966134f41bbd26f09f1"}`
- old pack scoring hashes: `{"screener_gate_candidates_v1.py": "2b0f11471f1a7997c3f7287808a4ca208b3ab11951dbf22de193ef795a143f46", "screener_gate_adapter_v1.py": "37557eeb4538839fd844d62c754e80ad0613e05d2fca0966134f41bbd26f09f1", "screener_gate_replay_v1.py": "037c7f5d89df0e0a717b7dd1e8ea88468621f9ca6a320f5e01c74a966d64f471"}`
- sessions: {'start': '2022-01-03', 'end': '2024-03-28', 'n': 562}
- complete open window: True
- entry invariant holds: True
- technical Top-20 versus old pack: `{"technical_top20_mismatch_days": 0, "aligned_with_old_technical_top20": true, "provenance_note": "new code reproduced the frozen #184 technical Top-20 on every checkpoint date; discovery lists still belong to this run's code hashes"}`
- discovery G2-G1 H20 close paired: `{"H": {"conditional_mean": -0.00035739693271642114, "n_days": 562, "n_valid": 560, "n_missing": 2, "ci95": [-0.0028628019403254437, 0.0021366013877252244], "reps": 2000, "seed": 174, "block": 20, "note": "same-day paired increment; missing calendar slots are kept and not concatenated"}, "2H": {"conditional_mean": -0.00035739693271642114, "n_days": 562, "n_valid": 560, "n_missing": 2, "ci95": [-0.0030593524250126453, 0.0021746722180552734], "reps": 2000, "seed": 174, "block": 40, "note": "same-day paired increment; missing calendar slots are kept and not concatenated"}, "percentiles": {"p05": -0.029290231925841043, "p50": 0.0, "p95": 0.026815295946158207}}`
- added and removed names are grouped on their own; an empty group is not zero
- no compounded overlapping-label drawdown
- holdout 2024-07-01+ not crossed
- suffix-classified broad slices are not a G1 reference
- pr184_review_fixes.patch was not attached; boundary guards were reconstructed from REVIEW(4)
