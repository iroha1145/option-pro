# Validation — metrics v2

This directory relabels frozen #184 technical Top-K ids. It does not replace return_pack/.

- production anchor: `d16b25e3812dce9adf16e2ca993b4f2c38d7b1ef`
- yahoo bars sha256: `1e48727adbd6abc055f6b9c759d371c07ead1fbc177d4b13deadbdc5d68ae589`
- label code sha256: `30fe4e0ad4b861579395917cc3ebe1ffbeedbdaa4e03200990b491c1de344efd`
- scoring hashes kept from the old manifest: `{"screener_gate_candidates_v1.py": "2b0f11471f1a7997c3f7287808a4ca208b3ab11951dbf22de193ef795a143f46", "screener_gate_adapter_v1.py": "37557eeb4538839fd844d62c754e80ad0613e05d2fca0966134f41bbd26f09f1", "screener_gate_replay_v1.py": "037c7f5d89df0e0a717b7dd1e8ea88468621f9ca6a320f5e01c74a966d64f471"}`
- sessions: {'start': '2022-01-03', 'end': '2024-03-28', 'n': 562}
- G1-B0 H20 close paired bootstrap: `{"H": {"conditional_mean": -6.986651832404765e-07, "n_days": 562, "n_valid": 560, "n_missing": 2, "ci95": [-4.537625867382349e-05, 4.328026312410206e-05], "reps": 2000, "seed": 174, "block": 20, "note": "same-day paired increment; missing calendar slots are kept and not concatenated"}, "2H": {"conditional_mean": -6.986651832404765e-07, "n_days": 562, "n_valid": 560, "n_missing": 2, "ci95": [-4.537625867382349e-05, 4.312624083540419e-05], "reps": 2000, "seed": 174, "block": 40, "note": "same-day paired increment; missing calendar slots are kept and not concatenated"}, "percentiles": {"p05": 0.0, "p50": 0.0, "p95": 0.0}}`
- discovery Top-K: not recovered from discovery_n; left null
- empty baskets stay null, not zero
- no compounded overlapping-label drawdown
- holdout 2024-07-01+ not crossed
- suffix-classified broad slices are not used
